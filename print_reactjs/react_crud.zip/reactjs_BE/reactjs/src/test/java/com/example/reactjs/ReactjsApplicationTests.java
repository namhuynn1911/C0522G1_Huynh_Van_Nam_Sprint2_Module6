package com.example.reactjs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactjsApplicationTests {

    @Test
    void contextLoads() {
    }

}
