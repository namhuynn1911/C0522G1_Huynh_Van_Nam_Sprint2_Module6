package com.example.reactjs.model.decentralization;

public class SocialResponse {
    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
