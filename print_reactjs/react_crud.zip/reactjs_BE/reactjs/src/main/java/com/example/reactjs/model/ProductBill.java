package com.example.reactjs.model;

public class ProductBill {
}
