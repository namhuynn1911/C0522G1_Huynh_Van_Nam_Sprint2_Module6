package com.example.reactjs.model.bill;

public class BillType {
}
