package com.example.reactjs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactjsApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReactjsApplication.class, args);
    }

}
